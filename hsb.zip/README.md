# Hypixel Stats Discord Bot

Fetches data from the Hypixel API and assigns roles to Discord members. Built with [Discord.js](https://discord.js.org/#/) and [Hypixel API Reborn](https://www.npmjs.com/package/hypixel-api-reborn).

Made for **Daniyal Saiyan** by **LexiCodes**.

## Project folder structure

```
.
├── commands                # Most Command Files For Command Handler
|   .
|   ├──botinfo.js           # Bot Info Command
|   ├──help.js              # Help Command
|   ├──link.js              # Link A User
|   ├──ping.js              # Checks Bots API Ping
|   ├──stats.js             # Checks User Stats
|   ├──unlink.js            # Unlinks A User From Their Hypixel Account
├── img                     # Project images (.png)
|   .
|   ├──hypixel-logo.png     # Hypixel Logo
├── roles                   # Files To Handle Roles
|   .
|   ├──bblr.js              # BBLR Util
|   ├──fkdr.js              # FKDR Util
|   ├──level.js             # Level Util
|   ├──rank.js              # Rank Util
|   ├──wlr.js               # WLR Util
├── utils                   # All Utilities
|   .
|   ├──db-util.js           # DataBase Util
|   ├──filters.js           # Filter Util
|   ├──hypixel-api-util.js  # Hypixel API Util
|   ├──misc.js              # Misc Util
|   ├──stat-role.js         # Stat Role Util
|
├── deploy-commands.js      # Registers All Commands To The Discord Server
├── index.js                # Main Bot Script
├── package-lock.json       # Server Side NPM
├── package.json            # NPM Dependencides
|
├── requirements.md         # Project Requirements Set By Danital Saiyan
├── todo.md                 # Discord Bot To-Do List
└── README.md               # Read Me File

```


## Commands

All commands for this bot are exclusively registered as [slash commands](https://support.discord.com/hc/en-us/articles/1500000368501-Slash-Commands-FAQ#:~:text=Slash%20Commands%20are%20the%20new,command%20right%20the%20first%20time.).

`/ping`
Shows Bot Connection Latency.

`/help`
Displays The Help Embed.

`/link [required:player]`
Links Your Hypixel And Discord accounts.

`/unlink`
Unlinks Your Hypixel And Discord Accounts.

`/stats [optional:player]`
Displays Hypixel Bedwars Statistics Of Yourself Or Another Player.
And If The ```Player``` Argument Isn't Provided, Then This Command Will Show The Stats Of The Member Who Invoked This Command.

## Usage

Instructions for running the bot.

### Prerequisites

- Create a bot application at the [Discord Developers Portal](https://discord.com/developers/applications).
- Install [Node.js](https://nodejs.org/) and [Git](https://git-scm.com/) on your machine.
- Clone this repo:
```
git clone https://github.com/LexiCodesOfficial/Hypixel-Stats-Bot-Main
``` 

### Project setup
```
npm install
```

### Configuration

Create a `config.json` file in the project root directory. Remove the following placeholders, then enter your credentials and IDs:
```json
{
  "clientID": "bot-clientid-goes-here",
  "guildID": "server-guildid-goes-here",
  "token": "discord-bot-token-goes-here",
  "hypixel-api-key": "hypixel-api-key-goes-here",
  "refresh": 0
}
```

Keys explained:
- `clientID`: ID of the bot
- `guildID`: ID the server where the bot will operate
- `token`: Discord bot token. You can get this from the [Discord Developers Portal](https://discord.com/developers/applications).
- `hypixel-api-key`: [Hypixel Public API](https://api.hypixel.net/) access key. You can get this by accessing the Hypixel server in Minecraft and using the `/api` command.
- `refresh`: Number of milliseconds between each server member role update. **_Highly recommended to keep this value over 5000ms_** to avoid getting rate-limited by the Hypixel API. 

### Database initialization

Create a `db.json` file in the project root directory - this acts as the bot's database. Simply enter an empty object like so: 

```json
{}
```

### Register commands

This bot uses a dedicated slash command handler and thus requires registering the commands beforehand to ensure proper functionality.

```
npm run commands
```

### Run Bot

To run this bot, use:

```
node .
```

or...

```
npm run bot
```

Alternatively, use [PM2](https://www.npmjs.com/package/pm2) to start the bot:

```
pm2 start bot
```


### Server Template Backup Link

[Lobby 1](https://discord.new/dvWjmGueH5ta)
