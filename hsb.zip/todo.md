# *Hypixel Stats Bot* To-do list

## Known Issues
- [x] ~~Add appropriate error handling for nonexistent players~~
- [x] ~~WLR and BBLR data doesn't match with Observer bot (benchmark)~~
- [x] ~~Clean up code~~

## Fetching Data
- [x] ~~Player Rank in Hypixel~~
- [x] ~~Bedwars stats~~
  - [x] ~~FKDR~~
  - [x] ~~W/L~~
  - [x] ~~Winstreak~~
  - [x] ~~B/L~~
  - [X] ~~Bedwars Levels~~

## Role Categories
- [x] ~~Implement logic for assigning Roles~~
- [x] ~~If stat changes, remove old role~~
- [x] ~~Break up role logic into individual modules~~
- [x] ~~Remove duplicate code~~

## Commands
- [x] ~~Create slash command handler~~
- [x] ~~Ping: `/ping` (see [below](#ping))~~
- [x] ~~Link: `/link` (see [below](#link-users))~~
- [x] ~~Unlink: `/unlink` (see [below](#unlink-users))~~
- [x] ~~Help: `/help` (see [below](#help-page))~~
- [x] ~~Stats: `/stats` (see [below](#user-stats))~~
  
### Ping
- [x] ~~Reply, show connection latency~~

### Link Users
- [x] ~~Implement main logic for linking Discord & Hypixel accounts~~
- [x] ~~Handle nonexistent player error~~
- [x] ~~If already registerd, prompt user to unlink first~~
- [x] ~~If user hasn't Discord in their social, prompt member to link Discord on `mc.hypixel.net` first~~

### Unlink Users
- [x] ~~Implement mainlogic for unlinking Discord & Hypixel accounts~~
- [x] ~~If not linekd, Prompts user~~

### Help page
- [x] ~~Create Help page~~
- [X] ~~Add as Rich Embed~~

### User Stats
- [x] ~~Improve message formatting~~
- [x] ~~Add option to query any Hypixel player~~
- [x] ~~Register as slash command~~

## Database
- [x] ~~Switch all DB operations to `fs` Promise-based API~~
- [x] ~~Create `db-util.js` module~~

## Configuration
- [x] ~~Remove duplicate config + .env file~~

## README.md
- [X] Re-read, check all sections, including `USAGE`