// Import Packages
const fs = require("fs");
const { Client, Intents, Collection } = require("discord.js");

// Custom Module Imports
const { assign_stat_role } = require("./utils/stat-role");
const { getDB, setDB } = require("./utils/db-util");
const { status } = require("./web/Status");

// Configuration Imports
const config = require("./config.json");
const hypixel = require("./utils/hypixel-api-util");

const client = new Client({
  intents: [
    Intents.FLAGS.GUILDS,
    Intents.FLAGS.GUILD_MESSAGES,
    Intents.FLAGS.GUILD_MEMBERS,
  ],
});

// Check If There Is A DataBase (DB) File
fs.exists("./db.json", (exists) => {
  console.log(exists ? "Found DB File" : "Didn't Find DB File... Making One.");
  exists
    ? ""
    : fs.writeFile("db.json", "{}", function (err) {
        if (err) throw err;
        console.log("File Created Successfully.");
      });
});

// Initialize Web Data
status();
// Initialize Commands
client.commands = new Collection();
const commandFiles = fs
  .readdirSync("./commands")
  .filter((file) => file.endsWith(".js"));

for (const file of commandFiles) {
  const command = require(`./commands/${file}`);
  client.commands.set(command.data.name, command);
}

// Status
client.once("ready", () => {
  console.log("Bot Is Ready.");
  client.user.setActivity("Music And Chilling", { type: "LISTENING" });
  client.user.setStatus("dnd");
});

// Check If There Was An Error While Executing Commands And If So To Send An Error Message
client.on("interactionCreate", async (interaction) => {
  if (!interaction.isCommand()) return;

  const command = client.commands.get(interaction.commandName);
  if (!command) return;

  try {
    await command.execute(interaction);
  } catch (error) {
    console.error(error);
    await interaction.reply({
      content: "There Was An Error While Executing This Command!",
      ephemeral: true,
    });
  }
});

// Request Queue
let queue = [];

// Push Request To Queue
setInterval(async () => {
  // Create db Variable From getDB Function
  let db = await getDB();

  for (const memberTag of Object.keys(db)) {
    // Get Member Tag
    const member = db[memberTag];

    // Only Push Once Refresh Expires
    if (Date.now() - member.latest < config.refresh) return;
    else {
      // Only Push If Not Already Queued
      for (const entry of queue) {
        if (entry.name === member.name) return;
      }

      // Push To Queue
      queue.push(member);
    }
  }
}, 2500);

// Request Data From API
if ((process.env.lock = "false")) {
  setInterval(async () => {
    if (queue.length === 0) return;
    else {
      // Get First Entry In Request Queue
      const entry = queue.shift();

      // Log Which User Is Being Processed
      // Disabled Due To The Fact It Spams Console
      // console.log(`Processing ${entry.name}`);

      try {
        // Make Request
        const player = await hypixel
          .getPlayer(entry.name)
          .catch((e) => console.error(e));

        const bw = player.stats.bedwars;

        // Get List Of Guild Roles
        let guild = client.guilds.cache.get(config.guildID);
        const roles = await guild.roles.fetch();

        // Get Target Members
        const members = await guild.members.fetch();
        const member = members.get(entry.id);

        // Level Roles
        assign_stat_role("level", bw.level, roles, member);

        // rank Roles
        assign_stat_role("rank", player.rank, roles, member);

        // FKDR Roles
        assign_stat_role("fkdr", bw.finalKDRatio, roles, member);

        // BBLR Roles
        assign_stat_role("bblr", bw.beds.BLRatio, roles, member);

        // WLR Roles
        assign_stat_role("wlr", bw.WLRatio, roles, member);

        // Update Record In DataBase (DB)
        let db = await getDB();

        // Update DataBase (DB) File
        for (let member of Object.values(db)) {
          if (member.name === entry.name) {
            member.latest = Date.now();
            return await setDB(db);
          }
        }
      } catch (error) {
        console.log(`>>>${entry.name}`);
      }
    }
  }, 2000);
} else {
  return true;
}

// Login To Discord
client.login(config.token);
