// get_rank_role
//  -> takes list of avaialble `rank_roles` in guild and `rank` value
//  -> returns appropriate `rank_role`
function get_rank_role(rank_roles, rank) {
  return rank_roles.find((r) => r.name.includes(rank));  
}

module.exports = { get_rank_role };