// custome module imports
const { roundDown } = require('../utils/misc');

// get_level_role
//  -> takes list of avaialble `level_roles` in guild and `level` value
//  -> returns appropriate `level_role`
function get_level_role(level_roles, level) { 

  if (level > 100) {
    return level_roles.find((r) =>
      // r.name.substring(0, r.name.length - 1) === roundDown(level, 100).toString()
      r.name.substring(0, r.name.length - 1) === roundDown(level, 100).toString()
    );
  } else if (level > 50) {
    return level_roles.find((r) => r.name === "50✫");
  } else {
    return level_roles.find((r) => r.name === "0✫");
  }
}

module.exports = { get_level_role };