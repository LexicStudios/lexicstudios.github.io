// custome module imports
const { roundDown } = require('../utils/misc');

// get_fkdr_role
//  -> takes list of avaialble `fkdr_roles` in guild and `fkdr` value
//  -> returns appropriate `fkdr_role`
function get_fkdr_role(fkdr_roles, fkdr) {

  // fkdr = 34.7

  if (fkdr >= 1000) {
    return fkdr_roles.find((r) => r.name.includes('1K+'));
  }
  else if (fkdr > 300) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 100))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 100).toString()
    );
  }
  else if (fkdr > 100) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 50))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 50).toString()
    );
  }
  else if (fkdr > 50) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 10))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 10).toString()
    );
  }
  else if (fkdr > 30) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 5))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 5).toString()
    );
  }
  else if (fkdr > 10) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 1))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 1).toString()
    );
  }
  else if (fkdr > 0) {
    return fkdr_roles.find((r) =>
      // r.name.includes(roundDown(fkdr, 0.5))
      r.name.substring(0, r.name.length-5) === roundDown(fkdr, 0.5).toString()
    );
  }
  else console.error("Couldn't find FKDR role!!!");

}

module.exports = { get_fkdr_role };