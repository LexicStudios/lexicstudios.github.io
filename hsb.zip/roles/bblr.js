// custome module imports
const { roundDown } = require('../utils/misc');

// get_bblr_role
//  -> takes list of avaialble `bblr_roles` in guild and `bblr` value
//  -> returns appropriate `bblr_role`
function get_bblr_role(bblr_roles, bblr) {

  // bblr = 0.75

  if (bblr >= 100) {
    return bblr_roles.find((r) => r.name.includes('100+'));
  }
  else if (bblr > 50) {
    return bblr_roles.find((r) =>
      // r.name.includes(roundDown(bblr, 10))
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 10).toString()
    );
  }
  else if (bblr > 20) {
    return bblr_roles.find((r) =>
      // r.name.includes(roundDown(bblr, 5))
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 5).toString()
    );
  }
  else if (bblr > 10) {
    return bblr_roles.find((r) =>
      // r.name.includes(roundDown(bblr, 2))
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 2).toString()
    );
  }
  else if (bblr > 5) {
    return bblr_roles.find((r) =>
      // r.name.includes(roundDown(bblr, 1))
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 1).toString()
    );
  }
  else if (bblr > 1) {
    return bblr_roles.find((r) =>
      // r.name.includes(`${roundDown(bblr, 0.5)} BBLR`)
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 0.5).toString()
    );
  }
  else if (bblr > 0) {
    return bblr_roles.find((r) =>
      // r.name.includes(`${roundDown(bblr, 0.25)} BBLR`)
      r.name.substring(0, r.name.length-5) === roundDown(bblr, 0.25).toString()
    );
  }
  else console.error("Couldn't find bblr role!!!");

}

module.exports = { get_bblr_role };