// custome module imports
const { roundDown } = require('../utils/misc');

// get_wlr_role
//  -> takes list of avaialble `wlr_roles` in guild and `wlr` value
//  -> returns appropriate `wlr_role`
function get_wlr_role(wlr_roles, wlr) {

  // wlr = 0.27

  if (wlr >= 100) {
    return wlr_roles.find((r) => r.name.includes('100+'));
  }
  else if (wlr > 50) {
    return wlr_roles.find((r) =>
      // r.name.includes(roundDown(wlr, 10))
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 10).toString()
    );
  }
  else if (wlr > 20) {
    return wlr_roles.find((r) =>
      // r.name.includes(roundDown(wlr, 5))
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 5).toString()
    );
  }
  else if (wlr > 10) {
    return wlr_roles.find((r) =>
      // r.name.includes(roundDown(wlr, 2))
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 2).toString()
    );
  }
  else if (wlr > 5) {    
    return wlr_roles.find((r) =>
      // r.name.includes(roundDown(wlr, 1))
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 1).toString()
    );
  }
  else if (wlr > 1) {
    return wlr_roles.find((r) =>
      // r.name.includes(`${roundDown(wlr, 0.5)} WLR`)
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 0.5).toString()
    );
  }
  else if (wlr > 0) {
    return wlr_roles.find((r) =>
      // r.name.includes(`${roundDown(wlr, 0.25)} WLR`)
      r.name.substring(0, r.name.length-4) === roundDown(wlr, 0.25).toString()
    );
  }
  else console.error("Couldn't find wlr role!!!");
}

module.exports = { get_wlr_role };