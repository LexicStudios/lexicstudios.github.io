// Package Imports
const { SlashCommandBuilder } = require('@discordjs/builders');
const { getDB, setDB } = require("../utils/db-util");
const { filter_bblr, filter_rank, filter_fkdr, filter_level, filter_wlr } = require("../utils/filters");

module.exports = {
    data: new SlashCommandBuilder()
        .setName('unlink')
        .setDescription('Unlinks Your Discord And Hypixel Accounts'),
    async execute(interaction) {

        let msg = "";
        let ephemeral = false;

        // Extract Data From Interaction
        const userTag = interaction.member.user.tag;

        // Get DB
        let db = await getDB();

        if (db.hasOwnProperty(userTag)) {

            // Remove All Stats Roles
            const roles = interaction.member.roles.cache;
            interaction.member.roles.remove(roles.find(r => filter_level(r)));
            interaction.member.roles.remove(roles.find(r => filter_rank(r)));
            interaction.member.roles.remove(roles.find(r => filter_fkdr(r)));
            interaction.member.roles.remove(roles.find(r => filter_bblr(r)));
            interaction.member.roles.remove(roles.find(r => filter_wlr(r)));
            console.log(roles.find(r => filter_level(r)))
            console.log(roles.find(r => filter_rank(r)))
            console.log(roles.find(r => filter_fkdr(r)))
            console.log(roles.find(r => filter_bblr(r)))
            console.log(roles.find(r => filter_wlr(r)))

            msg = `Successfully Unlinked \`${userTag}\` And **${db[userTag].name}**.`

            // Delete Entry From Database
            process.env.lock = 'true'
            delete db[userTag];
            process.env.lock = 'false'

        } else {
            msg = `You're Not Currently Linked To Any Account.`
            ephemeral = true;
        }

        // Update DB File    
        await setDB(db);

        // Reply
        return await interaction.reply({
            content: msg,
            ephemeral
        });
    },
};
