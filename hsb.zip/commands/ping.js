// Package Imports
const { SlashCommandBuilder } = require('@discordjs/builders');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ping')
        .setDescription('Test connection to bot and check latency.'),
    async execute(interaction) {
        // Calculate Ping
        msg = `🏓 Pong! Latency is ${Math.abs(interaction.createdTimestamp - Date.now())}ms.`
        ephemeral = true;
        await interaction.reply({
            content: msg,
            ephemeral,
        });
        
    },
};