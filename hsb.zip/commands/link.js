// Package Imports
const { SlashCommandBuilder } = require('@discordjs/builders');
const { getDB, setDB } = require("../utils/db-util");
const hypixel = require("../utils/hypixel-api-util");
const { assign_stat_role } = require("../utils/stat-role");

module.exports = {
	data: new SlashCommandBuilder()
        .setName("link")
        .setDescription("Links your Discord and Hypixel accounts.")
        .addStringOption((option) =>
            option
                .setName("player")
                .setDescription("The player account to link.")
                .setRequired(true)
        ),
    async execute(interaction) {
        // Create Variables
        let msg = "";
        let ephemeral = false;

        // Extract Data From Interaction
        const guildID = interaction.guildId.toString();
        const userTag = interaction.member.user.tag;
        const userID = interaction.member.user.id;
        const playerName = interaction.options.getString("player");

        // Log Data
        console.log("Got", guildID, userTag, playerName, __dirname);

        // Get DB
        let db = await getDB();

        // Check If User Is Already Linked
        if (!db.hasOwnProperty(userTag)) {
            // Fetch Player Data From API
            let player;

            try {
                player = await hypixel.getPlayer(playerName);
            } catch (e) {
                return interaction.reply({
                    content: `Player **${playerName}** wasn't found. Please try again.`,
                    ephemeral: true,
                });
            }

            // Scan For Social Media Accounts
            let scan_done = false;

            const socials = player.socialMedia;
            for (const s of socials) {
                if (s.id === "DISCORD") {
                    scan_done = true;
                    // Check If Tags Match
                    if (s.link === userTag) {
                        if (true) {
                            db[userTag] = {
                                id: userID,
                                name: playerName,
                                latest: 0,
                            };

                            // Success!

                            // Assign Roles Based On BW Stats
                            const bw = player.stats.bedwars;

                            // Get A List Of Guild Roles
                            const roles = await interaction.guild.roles.fetch();

                            // Get Target Member
                            const members = await interaction.guild.members.fetch();
                            const member = members.get(interaction.user.id);

                            // Level Roles
                            assign_stat_role("level", bw.level, roles, member);

                            // Rank Roles
                            assign_stat_role("rank", player.rank, roles, member);

                            // FKDR Roles
                            assign_stat_role("fkdr", bw.finalKDRatio, roles, member);

                            // BBLR Roles
                            assign_stat_role("bblr", bw.beds.BLRatio, roles, member);

                            // WLR Roles
                            assign_stat_role("wlr", bw.WLRatio, roles, member);

                            msg = `Sucessfully Linked \`${userTag}\` With **${playerName}**!`;
                            ephemeral = true;
                        }
                    } else {
                        msg = `Your Tag, \`${userTag}\`, Doesn't Match With **${playerName}**'s Tag, \`${s.link}\``;
                        ephemeral = true;
                    }
                }
            }

            // user hasn't linked Discord
            if (!scan_done) {
                msg =
                    "Discord Tag Not Found! Please Log Into ```mc.hypixel.net``` And Link Your Discord Account First.";
                ephemeral = true;
            }
        } else {
            // prompt to unlink
            msg = `You're Already Linked With **${db[userTag].name}**! To Change Your Linked Account, Please \`/unlink\` Your Account First.`;
            ephemeral = true;
        }

        // update DB file
        await setDB(db);

        // reply
        return await interaction.reply({
            content: msg,
            ephemeral,
        });
    },
};