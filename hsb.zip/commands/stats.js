// Package Imports
const { SlashCommandBuilder } = require('@discordjs/builders');
const { getDB } = require('../utils/db-util');
const hypixel = require('../utils/hypixel-api-util');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('stats')
        .setDescription('Displays your stats.')
        .addStringOption((option) =>
            option.setName("player")
                .setDescription("The player to get stats from.")
                .setRequired(false)
        ),
    async execute(interaction) {

        // Fetch DB
        let db = await getDB();

        // Extract Data From Interaction
        const userTag = interaction.member.user.tag;
        const option = interaction.options.getString('player');
        const playerName = (option === null ? db[userTag].name : option);

        if (db.hasOwnProperty(userTag)) {
            // Get Player From Hypixel API
            const player = await hypixel.getPlayer(playerName).catch(e => {
                interaction.reply({
                    content: "**An Error Occurred!** Please Check Player Name.",
                    ephemeral: true
                });
            });

            // Get Target's Bedwars Stats
            const bw = player.stats.bedwars;

            // build response embed message
            const embed = {
                "title": `Bedwars Stats`,
                "description": `Displaying Stats For Player **${playerName}**.`,
                "color": 5939811,
                "fields": [
                    {
                        "name": "Level",
                        "value": `${bw.level}`,
                        inline: true
                    },
                    {
                        "name": "Hypixel Rank",
                        "value": `${player.rank}`,
                        inline: true
                    },
                    {
                        "name": "FKDR",
                        "value": `${bw.finalKDRatio}`,
                        inline: true
                    },
                    {
                        "name": "BBLR",
                        "value": `${bw.beds.BLRatio}`,
                        inline: true
                    },
                    {
                        "name": "WLR",
                        "value": `${bw.WLRatio}`,
                        inline: true
                    },
                    {
                        "name": "Winstreak",
                        "value": `${bw.winstreak}`,
                        inline: true
                    }
                ]
            }
            interaction.reply({ embeds: [embed] });

        } else {
            interaction.reply({
                content: "Please Register First.",
                ephemeral: true
            });
        }

        return;

    },
};
