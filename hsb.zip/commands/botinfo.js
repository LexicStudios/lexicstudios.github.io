// Package Imports
const { SlashCommandBuilder } = require('@discordjs/builders');
const os = require('os');

module.exports = {
    data: new SlashCommandBuilder()
        .setName("botinfo")
        .setDescription("Bot Info"),
    async execute(interaction) {
        function format(seconds){
            function pad(s){
              return (s < 10 ? '0' : '') + s;
            }
            var hours = Math.floor(seconds / (60*60));
            var minutes = Math.floor(seconds % (60*60) / 60);
            var seconds = Math.floor(seconds % 60);
          
            return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds);
          }
          
          var uptime = os.uptime();
          var botup = process.uptime();
        const embed = {
            "title": "Bot Info",
            "description": "A list of bot info.",
            "color": 5939811,
            "fields": [
                {
                    "name": "RAM Usage",
                    "value": `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(0)}MB`,
                    inline: true
                },
                {
                    "name": "Cores",
                    "value": `${os.cpus().length}`,
                    inline: true
                },
                {
                    "name": "RAM",
                    "value": `${(os.totalmem() / 1024 / 1024).toFixed(0)}MB`,
                    inline: true
                },
                {
                    "name": "Ping",
                    "value": `${Math.abs(interaction.createdTimestamp - Date.now())}ms`,
                    inline: true
                },
                {
                    "name": "Server Uptime",
                    "value": `${format(uptime)}s`,
                    inline: true
                },
                {
                    "name": "Bot Uptime",
                    "value": `${format(botup)}s`,
                    inline: true
                },
                {
                    "name": "Node Version",
                    "value": `${process.version}`,
                    inline: true
                }
            ]
        };
        await interaction.reply({ embeds: [embed] });
    }
}