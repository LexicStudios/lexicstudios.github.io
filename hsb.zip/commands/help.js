const { SlashCommandBuilder } = require('@discordjs/builders');

const embed = {
    "title": "Help Page",
    "description": "A list of commands.",
    "color": 5939811,
    "fields": [
        {
            "name": "`/ping`",
            "value": "Shows Bot Connection Latency."
        },
        {
            "name": "`/botinfo`",
            "value": "Shows Bot Information. (Admin Only)"
        },
        {
            "name": "`/help`",
            "value": "Displays This Help Page."
        },
        {
            "name": "`/link [required:player]`",
            "value": "Links Your Hypixel And Discord Accounts."
        },
        {
            "name": "`/unlink`",
            "value": "Unlinks Your Hypixel And Discord Accounts."
        },
        {
            "name": "`/stats [optional:player]`",
            "value": "Displays Hypixel Bedwars Statistics Of Yourself Or Another Player.\n And If The `Player` Argument Isn't Provided, Then This Command Will Show The Stats Of The Member Who Invoked This Command."
        }
    ]
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Shows A Help Page.'),
    async execute(interaction) {
        await interaction.reply({ embeds: [embed], ephemeral: true, });
    },
};

