#!/bin/sh
sudo curl -s https://deb.nodesource.com/setup_16.x | sudo bash
sudo apt install nodejs -y
sudo apt install npm
npm i
node run start