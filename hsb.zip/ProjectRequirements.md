# Project requirements

## Main

* Bedwars stars
* Final Kill/Death Ratio (FKDR), not regular KDR

## Secondary

* Win/Lose ratio
* Win streaks
* Bed Break/Lose ratio
* Hypixel Ranks
