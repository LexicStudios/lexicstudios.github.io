// filtering functions
const filter_level = r => r.name.includes('❀') || r.name.includes('✪') || r.name.includes('✫');
const filter_rank = r => (r.name.includes('[') && r.name.includes(']'));
const filter_fkdr = r => (r.name.includes('FKDR'));
const filter_bblr = r => (r.name.includes('BBLR'));
const filter_wlr = r => (r.name.includes('WLR'))

module.exports = {
  filter_level,
  filter_rank,
  filter_fkdr,
  filter_bblr,
  filter_wlr
}