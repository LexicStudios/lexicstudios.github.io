const Hypixel = require('hypixel-api-reborn');
const config = require('../config.json');
module.exports = new Hypixel.Client(config['hypixel-api-key']);