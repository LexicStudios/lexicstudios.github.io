// snooze function
//  -> non-blocking Node.js sleeper
const snooze = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

// roundDown
//  -> rounds`num` down to the nearest spcified`interval`
function roundDown(num, interval) {
  return (Math.floor(num / interval) * interval).toString();
}

// addRole
//  -> adds the specified `role` to the specified `member`,
//     only if `member` doesn't already belong to `role`
function addRole(member, role) {
  if (!member.roles.cache.has(role.id)) {
    member.roles.add(role).catch((error) => {
      console.error(`Error: Adding role ${role.name}, to member ${member.user.tag}`, error);
    });
  }
}

module.exports = {
  snooze,
  roundDown,
  addRole,
};
