// package imports
const fs = require('fs/promises');

// path to database file
const db_path = __dirname + '/../db.json';

// getDB
//  -> reads and parses database file, returns database content as object
async function getDB() {
  const content = await fs.readFile(db_path);  
  return JSON.parse(content.toString());
}

// setDB
//  -> serializes input `object` as JSON and writes to database file
async function setDB(object) {
  return fs.writeFile(db_path, JSON.stringify(object));
}

module.exports = { getDB, setDB };
