// custom filters
const { filter_bblr, filter_fkdr, filter_level, filter_rank, filter_wlr } = require('./filters');

// custom role ranges
const { get_bblr_role }                                                   =  require('../roles/bblr');
const { get_fkdr_role }                                                   =  require('../roles/fkdr');
const { get_level_role }                                                  =  require('../roles/level');
const { get_rank_role }                                                   =  require('../roles/rank');
const { get_wlr_role }                                                    =  require('../roles/wlr');

// role add function
const { addRole }                                                         = require('./misc');

// assign_stat_role
//  -> assigns a role from `roles` to the specified `member` based on the provided `stat` and `value`
function assign_stat_role(stat, value, roles, member) {
  
  const stats = {
    'bblr':  [filter_bblr, get_bblr_role],
    'fkdr':  [filter_fkdr, get_fkdr_role],
    'level': [filter_level, get_level_role],
    'rank':  [filter_rank, get_rank_role],
    'wlr':   [filter_wlr, get_wlr_role],
  };

  if (!stats.hasOwnProperty(stat)) return console.error('Invalid stat!');

  // level roles
  const stat_roles = roles.filter(stats[stat][0]);    
  const stat_role =  stats[stat][1](stat_roles, value);

  // delete old level role, if member already has one, and it doesn't match new one
  const current_role = member.roles.cache.find(stats[stat][0]);    
  
  if (current_role !== undefined) {
    if (current_role.name != stat_role.name) {
      member.roles.remove(current_role);
    }
  }  
  
  return addRole(member, stat_role);
}

module.exports = { assign_stat_role };